"""Procedural sound design for 'What if the 1859 solar storm hit today?'.
Every cue sits on the same timeline as reel.html. Writes audio.wav (48 kHz stereo)."""
import json, os
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

ROOT = os.path.dirname(os.path.abspath(__file__))
TL = json.load(open(f'{ROOT}/timeline.json'))
SR = 48000
DUR = TL['duration']
N = int(SR * DUR)
t = np.arange(N) / SR
rng = np.random.default_rng(1859)

def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)
def lp(x, f, order=2): return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)
def noise(n=N): return rng.standard_normal(n)
def brown(n=N): b = np.cumsum(rng.standard_normal(n)); return hp(b, 20) / 60
def env(points, n=N): ts, gs = zip(*points); return np.interp(np.arange(n) / SR, ts, gs)
def db(x): return 10 ** (x / 20)
def place(dst, src, at, gain=1.0):
    i = int(at * SR)
    if i >= len(dst): return
    j = min(len(dst), i + len(src)); dst[i:j] += src[:j - i] * gain
def ir(seconds=2.6, decay=3.2, bright=6000):
    n = int(SR * seconds); r = lp(noise(n), bright) * np.exp(-np.arange(n) / SR * decay); return r / np.abs(r).sum() * 40
def reverb(x, wet=.35, **k): return x * (1 - wet) + fftconvolve(x, ir(**k))[:len(x)] * wet
def kf(arr, tt): return np.interp(tt, *zip(*arr))

L = np.zeros(N); R = np.zeros(N)
def add(sig, gain=1.0, pan=0.0, width=0.0):
    gl, gr = np.sqrt((1 - pan) / 2) * 1.414, np.sqrt((1 + pan) / 2) * 1.414
    if width:
        d = int(width * SR); L[:] += sig * gain * gl; R[d:] += sig[:-d] * gain * gr
    else:
        L[:] += sig * gain * gl; R[:] += sig * gain * gr

grid = kf(TL['grid'], t); crowd = kf(TL['crowd'], t); drive = kf(TL['drive'], t); aur = kf(TL['aurora'], t)
S = 33.4                                                 # v2 opens on the countdown: everything after it moved 33.4 s earlier
o = lambda x: x - S
SIL0, SIL1 = o(65.0), o(66.0)                            # the silence drop before the grid collapses
hush = env([(0, 1), (SIL0 - .25, 1), (SIL0, .04), (SIL1, .04), (SIL1 + .25, 1), (DUR, 1)])

# ---------- 1. city bed: traffic rumble + distant city air ----------
traffic = lp(brown(), 320) * (.5 + .5 * lp(np.abs(noise()), .3) / .3)
tr_lvl = np.clip(drive * (0.35 + 0.65 * np.clip(crowd, 0, 1)), 0, 1)
add(traffic * tr_lvl * hush, db(-11), width=.015)
air = bp(noise(), 300, 2500) * (.6 + .4 * lp(np.abs(noise()), .2) / .2)
add(air * env([(0, .5), (3.6, .55), (12.6, .9), (o(66), .9), (o(67), .45), (o(106), .45), (o(108.5), .7), (DUR, .7)]) * hush, db(-30), width=.02)
# car passes (doppler-ish swooshes) while traffic moves
pass_ = np.zeros(N)
for at in np.arange(1.0, DUR, 2.3):
    if kf(TL['drive'], at) < .5: continue
    n = int(SR * 2.4); tt = np.arange(n) / SR
    s = bp(noise(n), 200, 1800) * np.exp(-((tt - 1.2) / .55) ** 2)
    place(pass_, s, at + rng.random() * .8, .6 + rng.random() * .6)
add(pass_ * hush, db(-24), pan=-.45, width=.01)
# horns, now and then
def horn(dur=.35, f=410):
    n = int(SR * dur); tt = np.arange(n) / SR
    s = np.sign(np.sin(2 * np.pi * f * tt)) * .6 + np.sin(2 * np.pi * f * 1.26 * tt) * .5
    return bp(s * np.minimum(1, tt / .01) * np.minimum(1, (dur - tt) / .03), 300, 3000)
hn = np.zeros(N)
for at, f in [(2.1, 400), (6.2, 420), (7.8, 390), (8.1, 390), (10.8, 360), (o(48.4), 410), (o(110.4), 400), (o(116.0), 380), (o(126.4), 420)]:
    place(hn, horn(.25 + rng.random() * .3, f), at, 1)
add(reverb(hn, .45, seconds=1.8, decay=3.5), db(-31), pan=-.3)

# ---------- 2. billboard hum (60 Hz mains + buzz) ----------
hum_base = sum(np.sin(2 * np.pi * 60 * k * t) / k for k in (1, 2, 3, 5)) * .5
flk = kf(TL['flicker'], t)
crackle = (rng.random(N) < (.0006 + .02 * flk)) * rng.standard_normal(N) * 3
crackle = bp(crackle, 1500, 9000)
buzz = hp(np.tanh(hum_base * (1 + 6 * flk)) * (1 + flk * 3), 90)
add((buzz * grid * (0.35 + .65 * flk) + crackle * flk * 1.4) * hush, db(-24), width=.004)

# ---------- 3. crowd murmur ----------
babble = sum(bp(noise(), f * .8, f * 1.25) * (lp(np.abs(noise()), 3) * 6) for f in (300, 520, 900, 1400)) / 4
add(babble * np.clip(crowd, 0, 1) * env([(0, .35), (12.6, .9), (o(50), 1.0), (o(56), 1.15), (o(66), 1.0), (o(66.2), .25), (o(68), .6), (o(90), .5), (o(93.8), .12), (o(107.6), .12), (o(108.5), .5), (DUR, .5)]) * hush, db(-19), width=.02)
# "ooh" as the aurora appears and gasps when the lights die
def crowd_swell(at, dur, f0, f1, gain):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = np.interp(tt, [0, dur], [f0, f1])
    s = np.zeros(n)
    for k in range(14):
        ff = f * (1 + rng.normal(0, .06)); ph = 2 * np.pi * np.cumsum(ff) / SR + rng.random() * 6
        s += (np.sin(ph) + .5 * np.sin(2 * ph) + .3 * np.sin(3 * ph)) * (1 + .2 * np.sin(2 * np.pi * (4 + rng.random() * 3) * tt))
    s = bp(s / 14 + .3 * bp(noise(n), 300, 1500), 150, 2500) * np.sin(np.pi * np.clip(tt / dur, 0, 1)) ** 1.5
    x = np.zeros(N); place(x, s, at); add(reverb(x, .4), gain, width=.02)
crowd_swell(o(50.6), 3.2, 210, 170, db(-23))
crowd_swell(o(54.6), 2.6, 230, 190, db(-24))
crowd_swell(o(66.3), 1.4, 260, 210, db(-21))
# phone camera shutters
sh = np.zeros(N)
for at in np.sort(rng.uniform(o(54.8), o(59.5), 14)):
    n = int(SR * .06); tt = np.arange(n) / SR
    place(sh, hp(noise(n), 2500) * np.exp(-tt * 90) + hp(noise(n), 2500) * np.exp(-np.maximum(tt - .03, 0) * 120) * (tt > .03), at, .5 + rng.random() * .5)
add(sh, db(-27), pan=.3, width=.003)

# ---------- 4. news chime + radio static (the flare) ----------
def chime(at, g):
    n = int(SR * 1.6); tt = np.arange(n) / SR; s = np.zeros(n)
    for k, f in enumerate((880, 1318.5)):
        d = tt - k * .28; s += np.where(d > 0, np.sin(2 * np.pi * f * d) * np.exp(-np.maximum(d, 0) * 3.2), 0)
    x = np.zeros(N); place(x, s, at); add(reverb(x, .5, seconds=2.5, decay=2.4), g, pan=.15)
chime(0.15, db(-24)); chime(3.8, db(-26)); chime(8.0, db(-28))
# a faint high shimmer as the flare's light arrives
shim = sum(np.sin(2 * np.pi * f * t + rng.random() * 6) for f in (2637, 3136, 3951, 4699)) / 4
add(shim * env([(3.0, 0), (3.7, .7), (5.4, .3), (6.4, 0)]), db(-33), width=.01)

# ---------- 5. tension drone ----------
def drone(freqs, det=.5):
    s = np.zeros(N)
    for f in freqs:
        for k, dd in enumerate((-det, 0, det)):
            ph = 2 * np.pi * (f + dd) * t + k; s += np.sin(ph) + .25 * np.sin(2 * ph)
    return lp(s, 800) / (len(freqs) * 3)
lowD = drone([36.7, 55, 73.4])
add(lowD * env([(0, .3), (3.8, .45), (12.6, .9), (o(47), .5), (o(56.5), .55), (o(64.9), 1.0), (SIL0, 0), (SIL1, 0), (o(66.4), .6), (o(70), .35),
                (o(90), .3), (o(94), .4), (o(106), .4), (o(107.6), .2), (o(110), .25), (o(121), .35), (o(132.6), .6), (o(133.4), 0)]) * hush, db(-14))

# ---------- 6. time-lapse whooshes ----------
def whoosh(at, dur, gain, up=True):
    n = int(SR * dur); tt = np.arange(n) / SR; k = tt / dur
    s = noise(n); out = np.zeros(n)
    for i in range(0, n, 2400):
        f = 300 + 3500 * (k[i] ** 1.6 if up else (1 - k[i]) ** 1.6)
        seg = s[i:i + 2400]; out[i:i + 2400] = bp(seg, f * .7, min(f * 1.4, 20000))[:len(seg)]
    out *= np.sin(np.pi * k) ** 1.2
    x = np.zeros(N); place(x, out, at); add(x, gain, width=.02)
whoosh(3.3, 3.4, db(-20)); whoosh(6.3, 3.6, db(-23)); whoosh(9.3, 3.6, db(-22))
whoosh(o(89.9), 2.0, db(-21)); whoosh(o(91.8), 2.2, db(-21))
whoosh(o(105.6), 2.4, db(-19)); whoosh(o(107.4), 1.6, db(-21), up=False)
# day: pigeons and a far-off siren in the time-lapse
sir = np.zeros(N)
def siren(at, dur, gain, pan, fast=False):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = 750 + 380 * (np.sin(2 * np.pi * (1.8 if fast else .32) * tt) * .5 + .5)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) + .3 * np.sin(4 * np.pi * np.cumsum(f) / SR)
    s = lp(s, 2200) * np.sin(np.pi * tt / dur) ** .7
    x = np.zeros(N); place(x, s, at); add(reverb(x, .55, seconds=3, decay=2.2), gain, pan)
siren(1.2, 6, db(-36), .5); siren(7.6, 4, db(-34), -.6, True)
siren(o(69.5), 9, db(-30), -.5); siren(o(74.0), 11, db(-33), .6, True); siren(o(82.0), 9, db(-35), -.2)
siren(o(96.0), 8, db(-36), .5)

# ---------- 7. the hit at 8:36 PM ----------
def boom(at, gain, f=42, dec=1.6, crack=.0):
    n = int(SR * 4); tt = np.arange(n) / SR
    s = np.sin(2 * np.pi * f * tt * (1 - .25 * tt / 4)) * np.exp(-tt * dec) + lp(noise(n), 160) * np.exp(-tt * 2.5) * .8
    if crack: s += hp(noise(n), 1500) * np.exp(-tt * 25) * crack
    x = np.zeros(N); place(x, s, at); add(reverb(x, .35, seconds=3, decay=2), gain, width=.01)
# reverse swell into the arrival
n = int(SR * 2.0); rs = lp(noise(n), 900) * np.linspace(0, 1, n) ** 3
x = np.zeros(N); place(x, rs, o(44.6)); add(x, db(-20), width=.02)
boom(o(46.6), db(-9), 38, 1.2)

# ---------- 8. aurora: an airy, shimmering pad ----------
pad = np.zeros(N)
for f in (220, 277.2, 329.6, 440, 554.4, 659.3):
    for d in (-.7, .7):
        pad += np.sin(2 * np.pi * (f + d) * t + rng.random() * 6) * (.6 + .4 * np.sin(2 * np.pi * (.05 + rng.random() * .08) * t + rng.random() * 6))
pad = lp(pad / 12, 3000)
glass = sum(np.sin(2 * np.pi * f * t + rng.random() * 6) * (np.sin(2 * np.pi * (.11 + .03 * i) * t + i) * .5 + .5) ** 4 for i, f in enumerate((1760, 2217, 2637, 3322)))
add((pad + glass * .25) * aur * env([(0, 1), (o(66), 1), (o(66.4), 1.5), (o(90), 1.3), (DUR, 1)]) * hush, db(-22), width=.03)

# ---------- 9. transformers blowing ----------
for i, at in enumerate(TL['flashes']):
    n = int(SR * 2.2); tt = np.arange(n) / SR
    zap = np.sin(2 * np.pi * np.cumsum(900 * np.exp(-tt * 6) + 60) / SR) * np.exp(-tt * 5)
    zap += hp(noise(n), 1200) * np.exp(-tt * 9) * 1.6
    zap += np.tanh(np.sin(2 * np.pi * 120 * tt) * 8) * np.exp(-tt * 3) * .5
    x = np.zeros(N); place(x, zap, at); add(reverb(x, .45, seconds=2.4, decay=2.5), db(-14 - i * 1.2), pan=[-.4, .5, .1, -.2][i])
    boom(at + .04, db(-15 - i), 50, 2.2, crack=.6)

# ---------- 10. the collapse: everything spins down ----------
n = int(SR * 2.4); tt = np.arange(n) / SR
f = 180 * np.exp(-tt * 1.4) + 25
sd = (np.sin(2 * np.pi * np.cumsum(f) / SR) + .5 * np.sin(4 * np.pi * np.cumsum(f) / SR)) * np.exp(-tt * .9)
sd += lp(noise(n), 400) * np.exp(-tt * 2) * .4
x = np.zeros(N); place(x, sd, o(66.0)); add(x, db(-15), width=.01)
boom(o(66.0), db(-11), 34, 1.0)
# relays clunking off down the street
for k, at in enumerate(np.linspace(o(66.1), o(67.6), 7)):
    n = int(SR * .25); tt = np.arange(n) / SR
    c = (lp(noise(n), 900) + np.sin(2 * np.pi * 95 * tt)) * np.exp(-tt * 28)
    x = np.zeros(N); place(x, c, at + rng.random() * .1); add(x, db(-20 - k), pan=rng.uniform(-.7, .7))
# a car alarm in the dark
alarm = np.zeros(N)
n = int(SR * 14); tt = np.arange(n) / SR
pat = (np.sin(2 * np.pi * 2.2 * tt) > 0).astype(float)
s = np.sin(2 * np.pi * np.where(pat > 0, 1250, 980) * tt) * (np.floor(tt / 3) % 2 == 0) + np.sign(np.sin(2 * np.pi * 1600 * tt)) * .3 * (np.floor(tt / 3) % 2 == 1) * (np.sin(2 * np.pi * 9 * tt) > 0)
place(alarm, lp(s, 3500) * np.minimum(1, tt / .2) * np.minimum(1, (14 - tt) / 1.5), o(68.6))
add(reverb(alarm, .6, seconds=2.8, decay=2.4), db(-34), pan=.55)

# ---------- 11. the dark: wind, a dog, satellites fizzing in ----------
wmod = lp(np.abs(noise()), .4); wmod /= wmod.max()
wind = bp(noise(), 200, 1200) * (.4 + .6 * wmod)
add(wind * env([(0, .1), (o(66), .1), (o(68), .5), (o(90), .55), (o(94), .8), (o(106), .8), (o(108), .15), (DUR, .15)]) * hush, db(-21), width=.02)
for i, (at, _) in enumerate(TL['satellites']):
    n = int(SR * 1.6); tt = np.arange(n) / SR
    fz = bp(noise(n), 2500, 7000) * np.sin(np.pi * tt / 1.6) ** 2 * (1 + .5 * np.sin(2 * np.pi * 23 * tt))
    tone = np.sin(2 * np.pi * np.cumsum(np.linspace(3200, 2100, n)) / SR) * np.sin(np.pi * tt / 1.6) ** 3 * .3
    x = np.zeros(N); place(x, fz + tone, at); add(x, db(-31), pan=-.6 + i * .25)
# phones losing signal: a couple of soft error tones
for at, pan in [(o(87.0), .4), (o(88.3), -.3)]:
    n = int(SR * .5); tt = np.arange(n) / SR
    s = np.sin(2 * np.pi * np.where(tt < .2, 660, 523) * tt) * np.minimum(1, tt / .01) * np.exp(-np.maximum(tt - .2, 0) * 8) * (tt < .45)
    x = np.zeros(N); place(x, s, at); add(x, db(-31), pan)

# ---------- 12. day 3: a dry tap, a diesel generator that runs out ----------
n = int(SR * 2.2); tt = np.arange(n) / SR
tap = hp(noise(n), 700) * (np.sin(2 * np.pi * 7 * tt) * .5 + .5) * np.exp(-tt * 1.2) * .6
for k in range(6): tap += np.where(tt > .2 + k * .27, np.sin(2 * np.pi * 300 * (tt - .2 - k * .27)) * np.exp(-np.maximum(tt - .2 - k * .27, 0) * 30), 0) * .5
x = np.zeros(N); place(x, tap, o(94.4)); add(reverb(x, .3, seconds=1.2, decay=6), db(-24), pan=.25)
gen = kf(TL['generator'], t)
diesel = np.tanh(np.sin(2 * np.pi * 29 * t) * 3) + .5 * np.sin(2 * np.pi * 58 * t + 1) + .4 * lp(noise(), 300)
sputter = np.where((t > o(102.6)) & (t < o(104.6)), (np.sin(2 * np.pi * 3.1 * t) > -.2).astype(float), 1.0)
add(lp(diesel, 500) * gen * sputter * (1 - grid) * env([(0, 1), (o(93.8), .4), (o(94.2), 1), (DUR, 1)]), db(-28), pan=.5)
# crickets at night in the dead city
cr = np.zeros(N)
for at in np.arange(o(94.2), o(107.0), .9):
    n = int(SR * .6); tt = np.arange(n) / SR
    chirp = np.sin(2 * np.pi * 4400 * tt) * (np.sin(2 * np.pi * 28 * tt) > .2) * np.sin(np.pi * tt / .6)
    place(cr, chirp, at + rng.random() * .3, .5 + rng.random() * .5)
add(cr, db(-34), pan=-.4, width=.004)

# ---------- 13. 1859: telegraph clicks and sparks ----------
tg = np.zeros(N)
morse = '... --- .-.. .- .-. ... - --- .-. --'
at = o(121.1)
for ch in morse:
    if ch == ' ': at += .22; continue
    d = .07 if ch == '.' else .21
    n = int(SR * .03); tt = np.arange(n) / SR
    clk = (bp(noise(n), 1200, 5000) + np.sin(2 * np.pi * 2200 * tt)) * np.exp(-tt * 160)
    place(tg, clk, at, 1); place(tg, clk * .6, at + d, 1)
    at += d + .08
    if at > o(124.2): break
for at in (o(122.3), o(123.4)):
    n = int(SR * .5); tt = np.arange(n) / SR
    sp = hp(noise(n), 2500) * (rng.random(n) < .08) * np.exp(-tt * 9) * 3
    place(tg, sp, at, 1)
add(reverb(tg, .3, seconds=1.4, decay=4), db(-21), pan=-.2)

# ---------- 14. end card: the bed fades, one low note ----------
bed_out = env([(0, 1), (o(132.6), 1), (o(133.8), .06), (DUR, .06)])
L *= bed_out; R *= bed_out
endn = np.zeros(N); n = int(SR * 5); tt = np.arange(n) / SR
place(endn, (np.sin(2 * np.pi * 55 * tt) + .4 * np.sin(2 * np.pi * 110 * tt)) * np.minimum(1, tt / .05) * np.exp(-tt * .9), o(133.0), 1)
add(endn, db(-22))

# ---------- master ----------
mix = np.stack([L, R], 1)
mix = hp(mix.T, 25).T
mix = mix / np.percentile(np.abs(mix), 99.95) * db(-3)
mix = np.tanh(mix * 1.9) / np.tanh(1.9)
mix = mix / np.abs(mix).max() * db(-1.0)
# loop: the last 0.7 s crossfades into the opening bed, so the end runs straight back into frame 0
nl = int(SR * .7); ramp = np.linspace(0, 1, nl) ** 1.5
mix[-nl:] = mix[-nl:] * (1 - ramp[:, None]) + mix[:nl] * ramp[:, None]
wavfile.write(f'{ROOT}/audio.wav', SR, (mix * 32767).astype(np.int16))
blk = SR * 5; rms = [20 * np.log10(np.sqrt(np.mean(mix[i:i + blk] ** 2)) + 1e-9) for i in range(0, N, blk)]
print('dB per 5 s:', [round(x, 1) for x in rms])
