#!/bin/bash
cd /home/claude/storm
for seg in "0 28" "28 56" "56 84" "84 112" "112 139.5"; do
  set -- $seg
  out="seg_${1}.mp4"
  if [ ! -s "$out" ]; then python3 render.py video "$out" $1 $2 >> render.log 2>&1; echo "done $out $(date +%T)" >> render.log; fi
done
echo ALLDONE >> render.log
