# #03 — What if the 1859 solar storm hit today?

Still video: one fixed camera on Times Square, 1:44. It opens on the countdown: at 3 AM the Sun has just fired the storm, and the clock runs down 17 h 36 min to 8:36 PM in a time-lapse. Then the aurora, the blackout, day 3 and a year on. Nothing cuts or pans.

v2 (this version) cut the old 33 s slow opening. Everything after the countdown is unchanged, just 33.4 s earlier (`animOffset` in timeline.json keeps people, traffic, screens and the ticker in the same place, so the old frames were reused from 0:12.9 on).

## Files
- `timeline.json` — the script: captions, counters, timeline-bar marks, and every scene state as a keyframe curve (time of day, grid power, aurora, crowd, traffic, phones, torches, generator).
- `reel.html` — the three.js low-poly scene (rendered at 648×1152 with bloom) plus the 1080×1920 text layer in the #02 layout and the amber timeline bar.
- `audio.py` — procedural sound on the same timeline (city bed, billboard hum, news chimes, time-lapse whooshes, aurora pad, transformer blasts, silence drop, spin-down, car alarm, satellites, dry tap, generator, crickets, telegraph clicks).
- `render.py`, `render_all.sh` — headless Chromium (SwiftShader) to ffmpeg. About 0.9 s per frame, so about an hour for the whole reel.

## Re-render
```
npm i three@0.160.0 @fontsource/tinos
pip install playwright numpy scipy
python render.py preview prev 0 0.5 1 55 75 135     # check frames as JPGs
./render_all.sh                                     # renders in 28 s segments
python audio.py
ffmpeg -f concat -safe 0 -i segs.txt -c copy video_raw.mp4
ffmpeg -i video_raw.mp4 -i audio.wav -c:v copy -c:a aac -b:a 256k -movflags +faststart -shortest final.mp4
```

## Forwardable lines (VIDEO-RULES 2)
1. "Miners in the Rockies woke at 1 AM and made breakfast." (1859: the aurora was bright enough to pass for dawn)
2. "In 2012, one just as big missed Earth by nine days." (also the end-card fact)
3. Starlink, 2022: a minor storm took down 38 brand-new satellites.

## Deviations from VIDEO-RULES
- None in v2. Frame 0 has the title and the countdown, which starts ticking at once; the first caption lands at 0.3 s.
- Rule 3 (loop): the end card stays black, as the style spec says, but runs about 4 s, and the last 0.7 s fades back into the opening shot, picture and sound.

## Facts used (checked)
- Carrington Event: flare seen 1 Sept 1859; the plasma cloud arrived in 17.6 hours; auroras seen as far south as Cuba and Hawaii; telegraphs sparked, shocked operators and set paper on fire (Space.com; NASA).
- Gold miners in the Rockies got up and made breakfast at 1 AM; people read newspapers by the aurora's light (NOAA NESDIS).
- X-class is the strongest flare class; light from the Sun takes about 8 min 20 s; X-ray flares black out shortwave radio on Earth's sunlit side.
- March 1989: Quebec's grid collapsed in about 90 seconds, leaving 6 million people without power for 9 hours (Windows to the Universe).
- February 2022: 38 of 49 newly launched Starlink satellites were lost to a minor geomagnetic storm (CIRES).
- NYC buildings over five stories rely on electric pumps to fill roof tanks; residents lost water in the 2003 blackout (NYC DEP).
- Large power transformers: 80–120 week lead times (Wood Mackenzie via Utility Dive).
- Lloyd's (2013): 20–40 million people in the US at risk, outages from weeks to 1–2 years, $0.6–2.6 trillion in damage.
- July 2012: a Carrington-class CME missed Earth by about nine days (NASA; Wikipedia).
