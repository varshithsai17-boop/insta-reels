#!/bin/bash
cd /home/claude/storm
python3 render.py video v2_open.mp4 0 12.9 >> render3.log 2>&1; echo "done open $(date +%T)" >> render3.log
python3 render.py video v2_tail.mp4 98.6 104.2 >> render3.log 2>&1; echo "done tail $(date +%T)" >> render3.log
echo ALLDONE >> render3.log
