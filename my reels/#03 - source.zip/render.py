import sys, json, base64, subprocess, time, os, mimetypes
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.abspath(__file__))
tl = json.load(open(f'{ROOT}/timeline.json'))
ARGS = ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']
def serve(route):
    path = route.request.url.split('reel.local/', 1)[1].split('?')[0]
    fp = os.path.join(ROOT, path)
    if not os.path.isfile(fp): return route.fulfill(status=404, body='')
    ct = mimetypes.guess_type(fp)[0] or 'application/octet-stream'
    if fp.endswith('.js'): ct = 'text/javascript'
    route.fulfill(status=200, body=open(fp, 'rb').read(), headers={'content-type': ct})
def page_ready(p):
    b = p.chromium.launch(args=ARGS)
    page = b.new_page(viewport={'width': 1080, 'height': 1920})
    errs = []; page.on('pageerror', lambda e: errs.append(str(e))); page.on('console', lambda m: errs.append('console: ' + m.text) if m.type == 'error' else None)
    page.route('http://reel.local/**', serve)
    page.goto('http://reel.local/reel.html')
    page.wait_for_function('window.ready === true', timeout=60000)
    page.evaluate('document.fonts.load("400 40px Tinos")'); page.evaluate('document.fonts.load("italic 400 40px Tinos")'); page.evaluate('document.fonts.load("700 40px Tinos")')
    page.evaluate('document.fonts.ready.then(()=>1)')
    page.evaluate('(tl) => setup(tl)', tl)
    return page, errs
def grab(page, t, q=0.93):
    url = page.evaluate(f'(()=>{{renderFrame({t}); return document.getElementById("c").toDataURL("image/jpeg",{q});}})()')
    return base64.b64decode(url.split(',')[1])
if __name__ == '__main__':
    mode = sys.argv[1]
    with sync_playwright() as p:
        page, errs = page_ready(p)
        if mode == 'preview':
            out = sys.argv[2]; os.makedirs(out, exist_ok=True)
            for t in [float(x) for x in sys.argv[3:]]:
                st = time.time(); open(f'{out}/f_{t:06.1f}.jpg', 'wb').write(grab(page, t, .9)); print(t, round(time.time() - st, 2), flush=True)
        elif mode == 'video':
            out, t0, t1 = sys.argv[2], float(sys.argv[3]), float(sys.argv[4])
            fps = tl['fps']; n0, n1 = round(t0 * fps), round(t1 * fps)
            ff = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'image2pipe', '-framerate', str(fps), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', out], stdin=subprocess.PIPE)
            st = time.time()
            for n in range(n0, n1):
                ff.stdin.write(grab(page, n / fps))
                if n % 150 == 0: print(n, round(time.time() - st, 1), flush=True)
            ff.stdin.close(); ff.wait()
        if errs: print('PAGE ERRORS:', errs[:8])
