"""Procedural sound for 'What if you were inside the strongest tornado ever?' (#04).
Phone-mic POV: everything sits on the same timeline as reel.html. Writes audio.wav (48 kHz stereo)."""
import json, os
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

ROOT = os.path.dirname(os.path.abspath(__file__))
TL = json.load(open(f'{ROOT}/timeline.json'))
SR = 48000
DUR = TL['duration']
N = int(SR * DUR)
t = np.arange(N) / SR
rng = np.random.default_rng(1999)

def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)
def lp(x, f, order=2): return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)
def noise(n=N): return rng.standard_normal(n)
def brown(n=N): b = np.cumsum(rng.standard_normal(n)); return hp(b, 18) / 60
def env(points, n=N): ts, gs = zip(*points); return np.interp(np.arange(n) / SR, ts, gs)
def db(x): return 10 ** (x / 20)
def place(dst, src, at, gain=1.0):
    i = int(at * SR)
    if i >= len(dst) or i + len(src) <= 0: return
    j = min(len(dst), i + len(src)); dst[max(i, 0):j] += src[max(0, -i):j - i] * gain
def ir(seconds=2.0, decay=3.5, bright=6000):
    n = int(SR * seconds); r = lp(noise(n), bright) * np.exp(-np.arange(n) / SR * decay); return r / np.abs(r).sum() * 40
def reverb(x, wet=.35, **k): return x * (1 - wet) + fftconvolve(x, ir(**k))[:len(x)] * wet
L = np.zeros(N); R = np.zeros(N)
def add(sig, gain=1.0, pan=0.0, width=0.0):
    gl, gr = np.sqrt((1 - pan) / 2) * 1.414, np.sqrt((1 + pan) / 2) * 1.414
    if width:
        d = int(width * SR); L[:] += sig * gain * gl; R[d:] += sig[:-d] * gain * gr
    else:
        L[:] += sig * gain * gl; R[:] += sig * gain * gr

LIFT, THROW, LAND, AFTER, END = TL['liftAt'], TL['throwAt'], TL['landAt'], TL['afterAt'], TL['endAt']
storm = (t < AFTER - 1.4).astype(float)
# muffle for the ear-pop (37.0 -> 40.6) and for the stunned seconds after landing
muff = env([(0, 0), (36.95, 0), (37.05, 1), (39.6, 1), (40.8, 0), (LAND, 0), (LAND + .05, 1), (52.4, .7), (52.6, 0), (DUR, 0)])

# ---------- 1. the roar: freight-train rumble that builds as it closes in ----------
roar_src = lp(brown(), 260) * 1.8 + bp(noise(), 70, 420) * .6
roar_mod = 1 + .25 * lp(np.abs(noise()), 2) / .1
roar = roar_src * roar_mod
roar_lvl = env([(0, .45), (7, 1.0), (12, 1.0), (32.4, .95), (33.2, .45), (36.9, .45), (38.2, 1.0), (44, 1.05), (47.2, .7), (LAND, .55), (LAND + .1, .25), (53, .14), (AFTER - 1.4, 0), (DUR, 0)])
roar = roar * roar_lvl
roar = roar * (1 - muff) + lp(roar, 220) * muff * .8
add(np.tanh(roar * 1.3), db(-13), width=.012)

# ---------- 2. phone-mic wind: clipped, gusty, the sound of a phone in a storm ----------
gust = lp(np.abs(noise()), 1.2); gust = gust / gust.max()
wind = bp(noise(), 120, 2400) * (.35 + .65 * gust)
wind_lvl = env([(0, .6), (6, 1.0), (12, .9), (32.4, .8), (33.2, .25), (36.9, .25), (38.2, .9), (44, 1.0), (45, 1.4), (LAND, 1.2), (LAND + .1, .1), (53, .08), (AFTER, .12), (DUR, .12)])
mic = np.tanh(wind * wind_lvl * 2.6) * (1 - .8 * muff)
add(mic, db(-20), width=.004)

# ---------- 3. hail and debris hitting things near you ----------
hail = np.zeros(N)
for at in np.sort(rng.uniform(.2, LIFT, 220)):
    n = int(SR * .02); tt = np.arange(n) / SR
    place(hail, hp(noise(n), 2500) * np.exp(-tt * 260), at, .3 + rng.random() * .7)
add(hail, db(-22), pan=.2, width=.003)
hits = np.zeros(N)
for at in np.concatenate([np.sort(rng.uniform(4, THROW + 2, 70))]):
    n = int(SR * .35); tt = np.arange(n) / SR
    f0 = 80 + rng.random() * 160
    s = (np.sin(2 * np.pi * f0 * tt) + lp(noise(n), 1500) * 1.4) * np.exp(-tt * (14 + rng.random() * 20))
    place(hits, s, at, .3 + rng.random() * .9)
add(hits * (1 - .7 * muff), db(-19), pan=.0, width=.006)
# whooshes as debris shoots past the phone
wz = np.zeros(N)
for at in np.sort(rng.uniform(LIFT, THROW + 3, 60)):
    n = int(SR * .7); tt = np.arange(n) / SR
    s = bp(noise(n), 500 + rng.random() * 900, 3000 + rng.random() * 3000) * np.exp(-((tt - .3) / .12) ** 2)
    place(wz, s, at, .4 + rng.random() * .8)
add(wz * (1 - .8 * muff), db(-19), pan=0, width=.01)

# ---------- 4. power lines arcing on the ground ----------
for i, at in enumerate(TL['powerFlashes']):
    n = int(SR * 1.2); tt = np.arange(n) / SR
    zap = hp(noise(n), 1500) * np.exp(-tt * 10) * 1.3 + np.tanh(np.sin(2 * np.pi * 120 * tt) * 6) * np.exp(-tt * 4) * .6
    boom = lp(noise(n), 200) * np.exp(-tt * 5) * 1.2
    x = np.zeros(N); place(x, zap + boom, at); add(reverb(x, .4, seconds=1.8, decay=3), db(-20 - (i % 3) * 2), pan=[-.5, .4, -.2, .6, -.4, .3, 0][i % 7])
# the town's warning siren, far away
n = int(SR * 9); tt = np.arange(n) / SR
f = 420 + 260 * (np.sin(2 * np.pi * .18 * tt - 1.2) * .5 + .5)
sir = lp(np.sin(2 * np.pi * np.cumsum(f) / SR) + .4 * np.sin(4 * np.pi * np.cumsum(f) / SR), 1800)
x = np.zeros(N); place(x, sir, 0); add(reverb(x * env([(0, 1), (6.5, 1), (7.5, 0), (DUR, 0)]), .6, seconds=3, decay=2), db(-27), pan=-.4)

# ---------- 5. lift-off: a rising rush ----------
def rush(at, dur, gain, up=True):
    n = int(SR * dur); tt = np.arange(n) / SR; k = tt / dur
    s = noise(n); out = np.zeros(n)
    for i in range(0, n, 2400):
        fc = 250 + 3800 * (k[i] ** 1.4 if up else (1 - k[i]) ** 1.4)
        seg = s[i:i + 2400]; out[i:i + 2400] = bp(seg, fc * .6, min(fc * 1.5, 20000))[:len(seg)]
    out *= np.sin(np.pi * k) ** 1.1
    x = np.zeros(N); place(x, out, at); add(x, gain, width=.02)
rush(6.4, 3.4, db(-12))
n = int(SR * 2.5); tt = np.arange(n) / SR
x = np.zeros(N); place(x, lp(noise(n), 120) * np.exp(-tt * 1.8) * 2, 7.0); add(x, db(-10))

# ---------- 6. inside: a howling whistle with resonances ----------
howl = sum(bp(noise(), f * .96, f * 1.04) * (0.5 + 0.5 * np.sin(2 * np.pi * (.13 + .05 * k) * t + k)) for k, f in enumerate([520, 780, 1150, 1640]))
howl_lvl = env([(0, 0), (9, 0), (12, .8), (32.4, .8), (33.2, .25), (36.9, .25), (38.2, .9), (45, .9), (47, 0), (DUR, 0)])
add(howl * howl_lvl * (1 - muff), db(-20), width=.01)
# the railcar: metal groan and a heavy doppler pass
n = int(SR * 3.6); tt = np.arange(n) / SR
groan = np.sin(2 * np.pi * np.cumsum(np.interp(tt, [0, 2.1, 3.6], [90, 140, 60])) / SR) * (1 + .5 * np.sin(2 * np.pi * 7 * tt))
groan += .6 * np.sin(2 * np.pi * np.cumsum(np.interp(tt, [0, 2.1, 3.6], [233, 310, 170])) / SR)
groan *= np.exp(-((tt - 2.1) / .9) ** 2)
pass_ = lp(noise(n), 700) * np.exp(-((tt - 2.1) / .45) ** 2) * 1.5
x = np.zeros(N); place(x, lp(groan, 1200) + pass_, 28.3); add(reverb(x, .3), db(-12), pan=.2, width=.008)
# stop sign / trampoline clanks
for at, pan in [(22.4, .3), (24.1, -.2), (25.9, .35), (27.2, -.3)]:
    n = int(SR * .5); tt = np.arange(n) / SR
    s = sum(np.sin(2 * np.pi * f * tt) * np.exp(-tt * (8 + j * 3)) for j, f in enumerate([523, 787, 1210, 1730])) / 4
    x = np.zeros(N); place(x, s, at); add(x, db(-27), pan)

# ---------- 7. the core: hollow drone, lightning ----------
hollow = sum(np.sin(2 * np.pi * f * t + p) for f, p in [(55, 0), (82.4, 1), (110, 2), (164.8, .5)]) / 4
add(lp(hollow, 400) * env([(0, 0), (32.6, 0), (33.4, 1), (36.8, 1), (37.6, 0), (DUR, 0)]), db(-17), width=.02)
for at in TL['lightning']:
    n = int(SR * 2.4); tt = np.arange(n) / SR
    crack = hp(noise(n), 1800) * np.exp(-tt * 30) * 2 + lp(noise(n), 160) * np.exp(-tt * 2.2) * 1.4 * (1 - np.exp(-tt * 40))
    x = np.zeros(N); place(x, crack, at); add(reverb(x, .5, seconds=2.4, decay=2.2), db(-11), pan=rng.uniform(-.4, .4), width=.01)

# ---------- 8. ears pop ----------
n = int(SR * .12); tt = np.arange(n) / SR
pop = lp(noise(n), 400) * np.exp(-tt * 60) * 2 + np.sin(2 * np.pi * 70 * tt) * np.exp(-tt * 30)
x = np.zeros(N); place(x, pop, 37.0); add(x, db(-9))

# ---------- 9. thrown out: rush, tumbling flutter, the fall ----------
n = int(SR * (LAND - THROW)); tt = np.arange(n) / SR
fall = hp(noise(n), 900) * (.4 + .6 * (tt / tt[-1]) ** 1.5) * (1 + .6 * np.sin(2 * np.pi * (1.2 + tt * .9) * tt))
x = np.zeros(N); place(x, fall, THROW); add(x, db(-13), width=.01)
rush(THROW - .6, 2.6, db(-12))
# impact: thud, glass crack, then ringing
n = int(SR * 1.5); tt = np.arange(n) / SR
thud = lp(noise(n), 140) * np.exp(-tt * 7) * 3 + np.sin(2 * np.pi * 52 * tt) * np.exp(-tt * 9) * 1.5
crk = hp(noise(n), 3000) * (rng.random(n) < .2) * np.exp(-tt * 25) * 2
x = np.zeros(N); place(x, thud + crk, LAND); add(x, db(-6))
n = int(SR * 4.2); tt = np.arange(n) / SR
ring = np.sin(2 * np.pi * 6200 * tt) * np.minimum(1, tt / .05) * np.exp(-tt * .55)
x = np.zeros(N); place(x, ring, LAND + .05); add(x, db(-30))
# rain on the grass while the phone lies there
rain = hp(noise(), 2200) * (.6 + .4 * lp(np.abs(noise()), 25) * 3)
add(rain * env([(0, 0), (LAND + .3, 0), (LAND + 1.2, .8), (52.5, .8), (53.0, 0), (DUR, 0)]), db(-24), width=.02)

# ---------- 10. aftermath: drips, birds, distant sirens, chainsaw, footsteps, radios ----------
air = bp(noise(), 300, 2000) * (.6 + .4 * lp(np.abs(noise()), .2) / .2)
add(air * env([(0, 0), (AFTER - .5, 0), (AFTER + .5, .5), (END, .5), (END + 1, .05), (DUR, .05)]), db(-21), width=.02)
dr = np.zeros(N)
for at in np.sort(rng.uniform(AFTER + .5, END, 70)):
    n = int(SR * .12); tt = np.arange(n) / SR
    f = 900 + rng.random() * 900
    place(dr, np.sin(2 * np.pi * np.cumsum(np.linspace(f, f * 1.6, n)) / SR) * np.exp(-tt * 45), at, .3 + rng.random() * .7)
add(reverb(dr, .3, seconds=1.0, decay=6), db(-23), pan=.3, width=.004)
bird = np.zeros(N)
for at in [57.3, 57.8, 63.1, 63.5, 71.2, 76.8, 77.1, 84.4, 84.9, 89.6]:
    n = int(SR * .25); tt = np.arange(n) / SR
    f = 3200 + 900 * np.sin(2 * np.pi * 11 * tt) + rng.random() * 600
    place(bird, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / .25) ** 2, at, .4 + rng.random() * .6)
add(reverb(bird, .4), db(-24), pan=-.5)
def siren(at, dur, gain, pan, wail=True):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = (650 + 450 * (np.sin(2 * np.pi * .25 * tt) * .5 + .5)) if wail else np.where(np.sin(2 * np.pi * 1.6 * tt) > 0, 960, 770)
    s = lp(np.sin(2 * np.pi * np.cumsum(f) / SR) + .3 * np.sin(4 * np.pi * np.cumsum(f) / SR), 2400) * np.sin(np.pi * tt / dur) ** .6
    x = np.zeros(N); place(x, s, at); add(reverb(x, .6, seconds=3, decay=2), gain, pan)
siren(AFTER + .3, 16, db(-26), -.5); siren(66, 14, db(-28), .4, False); siren(78, 13, db(-27), -.3)
saw = np.zeros(N); n = int(SR * 9); tt = np.arange(n) / SR
eng = np.tanh(np.sin(2 * np.pi * (95 + 25 * np.sin(2 * np.pi * .4 * tt)) * tt) * 4) + .5 * hp(noise(n), 1500) * (np.sin(2 * np.pi * .4 * tt) > 0)
place(saw, lp(eng, 3500) * np.sin(np.pi * tt / 9) ** .5, 61.0); place(saw, lp(eng, 3500)[:int(SR * 7)] * .8, 79.5)
add(reverb(saw, .5, seconds=2.5, decay=2.4), db(-30), pan=.6)
steps = np.zeros(N)
for a0, a1 in [(55.9, 63.3), (66.3, 70.0), (79.1, 80.4), (83.2, 85.0)]:
    for at in np.arange(a0, a1, .52):
        n = int(SR * .14); tt = np.arange(n) / SR
        crunch = bp(noise(n), 400, 5000) * np.exp(-tt * 28) + lp(noise(n), 300) * np.exp(-tt * 40) * .7
        place(steps, crunch, at + rng.random() * .05, .5 + rng.random() * .5)
add(steps, db(-18), width=.003)
beeps = np.zeros(N)
for at in [59.4, 68.8, 74.1, 81.9, 87.3]:
    n = int(SR * .5); tt = np.arange(n) / SR
    s = np.sin(2 * np.pi * 1450 * tt) * ((tt < .1) | ((tt > .16) & (tt < .24))) + bp(noise(n), 800, 3000) * .25 * (tt > .26) * np.exp(-(tt - .26) * 6)
    place(beeps, s, at, 1)
add(reverb(beeps, .4), db(-27), pan=-.6)

# ---------- 11. a low tension drone under the whole storm ----------
dr2 = sum(np.sin(2 * np.pi * (f + d) * t + k) for k, (f, d) in enumerate([(36.7, 0), (36.7, .4), (55, 0), (73.4, -.3)])) / 4
add(lp(dr2, 300) * env([(0, .5), (7, .9), (44, .9), (LAND, .6), (LAND + .2, 0), (AFTER, 0), (70, 0), (74, .5), (END, .6), (END + .8, 0), (DUR, 0)]), db(-17))

# ---------- 12. end card: the bed fades, one low note ----------
bed_out = env([(0, 1), (END - .4, 1), (END + .8, .05), (DUR, .05)])
L *= bed_out; R *= bed_out
endn = np.zeros(N); n = int(SR * 4.5); tt = np.arange(n) / SR
place(endn, (np.sin(2 * np.pi * 55 * tt) + .4 * np.sin(2 * np.pi * 110 * tt)) * np.minimum(1, tt / .05) * np.exp(-tt * .9), END, 1)
add(endn, db(-22))

# ---------- master ----------
mix = np.stack([L, R], 1)
mix = hp(mix.T, 25).T
mix = mix / np.percentile(np.abs(mix), 99.95) * db(-3)
mix = np.tanh(mix * 1.8) / np.tanh(1.8)
mix = mix / np.abs(mix).max() * db(-1.0)
mix = mix * db(float(os.environ.get('TRIM', '0')))
# loop: the last 0.7 s crossfades into the opening, so the end runs straight back into frame 0
nl = int(SR * .7); ramp = np.linspace(0, 1, nl) ** 1.5
mix[-nl:] = mix[-nl:] * (1 - ramp[:, None]) + mix[:nl] * ramp[:, None]
wavfile.write(f'{ROOT}/audio.wav', SR, (mix * 32767).astype(np.int16))
blk = SR * 5; rms = [round(float(20 * np.log10(np.sqrt(np.mean(mix[i:i + blk] ** 2)) + 1e-9)), 1) for i in range(0, N, blk)]
print('dB per 5 s:', rms)
