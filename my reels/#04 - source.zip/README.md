# #04 — What if you were inside the strongest tornado ever?

Moving video, 1:36, filmed as if on your phone: you hit record as the Moore tornado comes at you, get lifted, ride inside it (debris flying with you, a railcar, the hollow core lit by lightning, the ear-pop), get thrown out, and the phone lies in the grass still recording. An hour later a rescuer picks it up and walks through what is left.

## Files
- `timeline.json` — captions, counters, timeline bar (NOW · 7 SEC · 44 SEC · 1 HOUR), the REC timecode, lightning and power-flash cues, and the key moments (lift-off, throw-out, landing, aftermath).
- `reel.html` — three.js scene: a town grid that the tornado destroys as it passes (houses to slabs, roofs flying, trees stripped, poles down), the funnel as layered rotating shells with a debris ring, debris that rides along with the camera, the floating trampoline / stop sign / pickup / railcar / duck, the core with lightning, and the aftermath set (wrapped pickup, chair leg in a post, the bathroom with the duck in the tub, rescue trucks). The camera path is scripted per phase. Text layer is the #02 layout plus the timeline bar and a REC timecode.
- `audio.py` — phone-mic wind, the roar, hail, power-line arcs, the town siren, debris hits and whooshes, the inside howl, the railcar groan, lightning, the ear-pop muffle, the fall, the impact and ringing, rain, then drips, birds, sirens, a chainsaw, footsteps and radio beeps. `TRIM=-1.5` brings it to about −14 LUFS.
- `render.py`, `render_all.sh` — headless Chromium (SwiftShader) to ffmpeg, about 1.1 s per frame.

## Re-render
```
npm i three@0.160.0 @fontsource/tinos
pip install playwright numpy scipy
python render.py preview prev 0 7 33.15 50 60 90   # check frames as JPGs
./render_all.sh                                    # renders in 20 s segments
TRIM=-1.5 python audio.py
ffmpeg -f concat -safe 0 -i segs.txt -c copy video_raw.mp4
ffmpeg -i video_raw.mp4 -i audio.wav -c:v copy -c:a aac -b:a 256k -movflags +faststart -shortest final.mp4
```

## Forwardable lines (VIDEO-RULES 2)
1. "36 people died. Without warnings, it could have been 600."
2. "A 36,000-pound railcar flies past." (it was thrown three-quarters of a mile in 1999)
3. "In 2006, a teenager was carried 1,307 feet by a tornado. He woke up in a field. Alive."

## Deviations from VIDEO-RULES
- None. Frame 0 has the title and the funnel coming at you with the distance ticking down; the first caption lands at 0.3 s.
- Rule 3 (loop): the end card stays black per the style spec, runs about 4 s, and the last 0.7 s fades back into the opening shot, picture and sound.
- Small layout addition at Varshith's request: a "● REC" timecode at the top right, so it reads as phone footage.

## Facts used (checked)
- 1999 Bridge Creek–Moore tornado: 321 mph (517 km/h) measured by Doppler on Wheels, revised in 2021, the highest wind speed ever recorded in a tornado; 38 miles (61 km) path; 1 h 25 min on the ground; 36 direct deaths; NWS researchers estimated more than 600 deaths without the warnings; a 36,000-lb freight railcar thrown 0.75 miles; a lawn chair leg impaled in a post (Wikipedia).
- Fewer than 1% of tornadoes are violent (EF4–EF5), but they cause nearly two-thirds of tornado deaths; safest place is an interior room on the lowest floor (Penn State Meteo 3).
- A probe in the 2003 Manchester, South Dakota tornado recorded a 100 hPa pressure drop in under a minute (Tim Samaras, Wikipedia). 100 hPa is roughly the pressure change of rising 900 m near sea level.
- Matt Suter, 12 March 2006, near Fordland, Missouri: carried 398 m (1,307 ft) and woke in a field with minor injuries (Guinness World Records).
- Will Keller, 1928: looked up into a tornado and saw a hollow opening lit by constant lightning (Kansas Historical Society), used for the core shot.
