#!/bin/bash
cd /home/claude/tornado
for seg in "0 20" "20 40" "40 60" "60 80" "80 96.5"; do
  set -- $seg
  out="seg_${1}.mp4"
  if [ ! -s "$out" ]; then python3 render.py video "$out" $1 $2 >> render.log 2>&1; echo "done $out $(date +%T)" >> render.log; fi
done
echo ALLDONE >> render.log
