"""Procedural sound design for 'What if the oceans drained?'.
Every cue is placed on the same timeline as reel.html. Writes audio.wav (48 kHz stereo)."""
import json, os
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

ROOT = os.path.dirname(os.path.abspath(__file__))
TL = json.load(open(f'{ROOT}/timeline.json'))
SR = 48000
DUR = TL['duration']
N = int(SR * DUR)
t = np.arange(N) / SR
rng = np.random.default_rng(42)

def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)
def lp(x, f, order=2): return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)
def noise(n=N): return rng.standard_normal(n)
def brown(n=N):
    b = np.cumsum(rng.standard_normal(n)); return hp(b, 20) / 60
def env(points, n=N):  # piecewise-linear envelope from [(time, gain), ...]
    ts, gs = zip(*points); return np.interp(np.arange(n) / SR, ts, gs)
def db(x): return 10 ** (x / 20)
def place(dst, src, at, gain=1.0):
    i = int(at * SR); j = min(len(dst), i + len(src)); dst[i:j] += src[:j - i] * gain
def ir(seconds=2.6, decay=3.2, bright=6000):
    n = int(SR * seconds); r = lp(noise(n), bright) * np.exp(-np.arange(n) / SR * decay); return r / np.abs(r).sum() * 40
def reverb(x, wet=.35, **k): return x * (1 - wet) + fftconvolve(x, ir(**k))[:len(x)] * wet
def level_at(tt): return np.interp(tt, *zip(*TL['waterLevel']))

L = np.zeros(N); R = np.zeros(N)
def add(sig, gain=1.0, pan=0.0, width=0.0):
    """pan -1..1; width>0 decorrelates by a few ms."""
    gl, gr = np.sqrt((1 - pan) / 2) * 1.414, np.sqrt((1 + pan) / 2) * 1.414
    global L, R
    if width:
        d = int(width * SR); L[:] += sig * gain * gl; R[d:] += sig[:-d] * gain * gr
    else:
        L[:] += sig * gain * gl; R[:] += sig * gain * gr

# ---------- 1. surf (beach) : swells that fade as the sea retreats ----------
period = 6.8
swell = np.clip(np.sin(2 * np.pi * (t / period)) * .5 + .5, 0, 1) ** 2.2
swell = lp(swell, 2)
surf_near = bp(brown() + noise() * .15, 120, 3200) * (0.25 + swell)
surf_far = lp(surf_near, 700)
dist = np.clip((np.interp(t, *zip(*TL['waterLevel'])) * -1) / 60, 0, 1)   # 0 near .. 1 far
surf = surf_near * (1 - dist) + surf_far * dist
surf *= env([(0, 0), (.6, 1), (6.5, 1), (11, .6), (16, .25), (22, .08), (29.4, .03), (30, 0)])
add(surf, db(-14), width=.012)

# ---------- 2. gulls ----------
def gull(dur=.42, f0=1650, f1=1050):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = np.interp(tt, [0, dur * .25, dur], [f0 * .9, f0, f1]) * (1 + .03 * np.sin(2 * np.pi * 28 * tt))
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) + .45 * np.sin(2 * ph) + .2 * np.sin(3 * ph) + .25 * noise(n) * np.sin(ph)
    e = np.minimum(1, tt / .03) * np.exp(-tt * 3.5)
    return bp(s * e, 700, 5000)
for at, pan in [(1.2, -.5), (1.7, -.45), (5.2, .6), (8.9, -.2), (9.35, -.15)]:
    g = np.zeros(N); place(g, gull(f0=1500 + rng.random() * 400), at); add(reverb(g, .25), db(-28), pan)

# ---------- 3. wind / basin air / hot dry wind ----------
wmod = lp(np.abs(noise()), .4); wmod = wmod / wmod.max()
wind = bp(noise(), 250, 1400) * (.4 + .6 * wmod)
add(wind * env([(0, .04), (8, .06), (20, .2), (29.4, .3), (30, .25), (38.0, .3), (38.6, .02), (40.8, .02), (41.6, .12), (56, .12),
                (57, .18), (64.9, .25), (65.1, .03), (67, .12), (70, .05), (70.5, .06), (86.6, .06),
                (87, .3), (91.3, .3), (93.4, .12), (95.6, .3), (107.6, .3), (108, .05), (124.6, .05), (125, 0)]), db(-15), width=.02)

# ---------- 4. tension drone ----------
def drone(freqs, det=.6):
    s = np.zeros(N)
    for f in freqs:
        for k, dd in enumerate((-det, 0, det)):
            ph = 2 * np.pi * (f + dd) * t + k
            s += np.sin(ph) + .25 * np.sin(2 * ph)
    return lp(s, 900) / (len(freqs) * 3)
lowA = drone([55, 82.41, 110])
add(lowA * env([(0, 0), (8, 0), (16, .35), (27, .7), (29.8, .9), (30.2, .6), (38.0, 1), (38.5, 0), (40.8, 0), (42, .6), (56, .4),
                (57, .5), (64.5, 1), (65.0, 1), (65.2, 0), (67, 0), (68.5, .4), (70, .2), (70.5, .25), (86.6, .5),
                (87, .3), (107.6, .55), (108, .25), (120, .3), (124.6, .2), (126, 0)]), db(-14))

# ---------- 5. hits / whoomps ----------
def whoomp(f0=72, f1=32, dur=2.2):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = f1 + (f0 - f1) * np.exp(-tt * 3); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-tt * 2.2) * np.minimum(1, tt / .01)
hits = np.zeros(N)
for at, g in [(8.25, .8), (15.7, .6), (23.7, .7), (41.0, 1.0), (65.05, .9), (67.3, .6), (70.6, .8), (74.7, .7), (78.9, .7), (99.9, .7), (112.2, .5)]:
    place(hits, whoomp(), at, g)
add(hits, db(-11))

# ---------- 6. draining rumble (beach) ----------
rumble = lp(brown(), 160) * env([(0, 0), (9, 0), (18, .5), (26, .85), (29.6, 1.0), (30.05, 0)])
add(rumble, db(-7), width=.008)

# ---------- 7. transitions (whooshes) ----------
def whoosh(dur=1.6, f0=3500, f1=180, rise=.8):
    n = int(SR * dur); tt = np.arange(n) / SR; x = noise(n); out = np.zeros(n); blk = 1024
    for i in range(0, n, blk):
        fc = f0 * (f1 / f0) ** (i / n); out[i:i + blk] = bp(x[i:i + blk], max(60, fc * .6), min(20000, fc * 1.6), 1)
    e = np.where(tt < rise * dur, (tt / (rise * dur)) ** 2, np.exp(-(tt - rise * dur) * 9))
    return lp(out, 6000) * e
wh = np.zeros(N)
place(wh, whoosh(1.7), 28.5, 1.0); place(wh, whoosh(1.4, 2500, 150), 54.9, .8); place(wh, whoosh(1.3, 1800, 120), 69.0, .6)
place(wh, whoosh(1.3, 3000, 400), 86.0, .5); place(wh, whoosh(1.3, 1800, 120), 107.0, .5)
add(wh, db(-12), width=.01)

# ---------- 8. rushing water (descent + trench) ----------
gurgle = np.clip(lp(noise(), 9) * 6 + .6, 0, None)
rush = bp(noise() * .7 + brown() * .8, 140, 1800) * gurgle
add(rush * env([(29.8, 0), (30.3, .55), (34, .8), (38.0, 1.1), (38.4, 0), (40.8, 0), (42.5, .06), (56, .05),
                (57, .2), (60, .7), (64.4, 1.5), (65.0, 1.6), (65.1, 0)]), db(-13), width=.015)

# ---------- 9. zone chimes ----------
def bell(f=196, dur=4.0):
    n = int(SR * dur); tt = np.arange(n) / SR
    s = sum(a * np.sin(2 * np.pi * f * m * tt) * np.exp(-tt * (1.2 + m * .6)) for m, a in [(1, 1), (2.76, .5), (5.4, .25), (8.9, .12)])
    return s * np.minimum(1, tt / .005)
ch = np.zeros(N); place(ch, bell(196), 33.0, 1); place(ch, bell(146.8), 35.0, .8)
add(reverb(ch, .5), db(-24))

# ---------- 10. Titanic: metal groan + resonances ----------
def groan(dur=5.5):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = 46 * (1 - .18 * tt / dur) * (1 + .02 * np.sin(2 * np.pi * 1.3 * tt))
    ph = 2 * np.pi * np.cumsum(f) / SR
    saw = sum(np.sin(k * ph) / k for k in range(1, 18))
    res = sum(np.sin(2 * np.pi * fr * tt + k) * np.exp(-tt * (0.5 + k * .15)) * a for k, (fr, a) in enumerate([(183, .5), (311, .35), (467, .3), (733, .2), (1012, .1)]))
    e = np.minimum(1, tt / .8) * np.exp(-np.maximum(0, tt - 1.5) * .7)
    return lp(saw, 700) * e * .6 + res * e * .5
gr = np.zeros(N); place(gr, groan(), 41.0, 1); place(gr, groan(3.5) * .6, 48.2, 1)
add(reverb(gr, .45, seconds=3.5, decay=1.6), db(-12))

# ---------- 11. pads (emotion) ----------
def pad(freqs, dur):
    n = int(SR * dur); tt = np.arange(n) / SR; s = np.zeros(n)
    for f in freqs:
        for dd in (-.8, 0, .8): s += np.sin(2 * np.pi * (f + dd) * tt + rng.random() * 6)
    s = lp(s, 1500) / (len(freqs) * 3)
    return s * np.minimum(1, tt / 3) * np.minimum(1, (dur - tt) / 3)
pd = np.zeros(N)
place(pd, pad([110, 130.81, 164.81, 220], 14), 42.2, 1)        # A minor - Titanic
place(pd, pad([98, 146.83, 196, 246.94], 4.5), 67.0, .9)       # G - Everest
place(pd, pad([87.31, 130.81, 174.61, 220], 17), 70.3, .9)     # F - consequences
place(pd, pad([73.42, 146.83, 174.61, 220], 21.5), 86.8, 1)    # D minor - the coast
place(pd, pad([65.41, 130.81, 164.81, 196], 17), 108.0, .9)    # C - upside / desert planet
add(reverb(pd, .4), db(-19), width=.02)

# ---------- 12. drips + creaks ----------
def drip(f=None):
    f = f or 900 + rng.random() * 1400; n = int(SR * .25); tt = np.arange(n) / SR
    fs = f * (1 + 1.5 * np.exp(-tt * 40)); return np.sin(2 * np.pi * np.cumsum(fs) / SR) * np.exp(-tt * 25)
dr = np.zeros(N)
for at in [38.8, 39.6, 40.3] + list(np.arange(42.5, 55.5, 1.7) + rng.random(8) * .8) + [65.6]:
    place(dr, drip(), at, .6 + rng.random() * .4)
add(reverb(dr, .5, seconds=3, decay=1.4), db(-22))
def creak(dur=.9):
    n = int(SR * dur); tt = np.arange(n) / SR
    pulses = (np.sin(2 * np.pi * (18 + 10 * tt) * tt) > .9).astype(float)
    return bp(lp(pulses, 4000) * np.sin(np.pi * tt / dur), 300, 2200)
cr = np.zeros(N)
for at in [43.8, 47.4, 50.2, 53.0]: place(cr, creak(), at, 1)
add(reverb(cr, .5), db(-26), pan=.2)

# ---------- 13. the duck ----------
def squeak(dur=.2):
    n = int(SR * dur); tt = np.arange(n) / SR
    f = np.interp(tt, [0, dur * .4, dur], [1650, 2350, 2050]) * (1 + .04 * np.sin(2 * np.pi * 40 * tt))
    ph = 2 * np.pi * np.cumsum(f) / SR; s = np.sin(ph) + .5 * np.sin(2 * ph) + .2 * np.sin(3 * ph)
    return s * np.minimum(1, tt / .01) * np.minimum(1, (dur - tt) / .04)
sq = np.zeros(N); place(sq, squeak(), 65.9, 1); place(sq, squeak(.16), 66.17, .8)
add(reverb(sq, .35), db(-26))

# ---------- 14. space (globe scenes) ----------
space = lp(noise(), 300) * env([(69.6, 0), (70.6, 1), (86.4, 1), (87, 0), (107.6, 0), (108.4, 1), (124.4, 1), (125, 0)])
add(space, db(-20), width=.02)

# ---------- 15. consequence cues ----------
# salt crystallising: a rising shimmer of tiny high plinks
salt = np.zeros(N)
for k in range(140):
    at = 74.6 + 3.2 * (k / 140) ** .7 + rng.random() * .05
    n = int(SR * .35); tt = np.arange(n) / SR; f = 2200 + rng.random() * 4200
    place(salt, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 18), at, .25 + .5 * rng.random())
add(reverb(salt, .5), db(-25), width=.01)
# rain that fades out ("the rain almost stops")
rain = hp(noise(), 1800) * (0.6 + 0.4 * lp(np.abs(noise()), 30) * 3)
add(rain * env([(76.6, 0), (77.6, .8), (79.0, .8), (82.4, 0)]), db(-24), width=.02)
# day/night time-lapse: two swells, crickets on the dark half
dn = np.zeros(N)
for c0 in (91.4, 93.5):
    n = int(SR * 2.1); tt = np.arange(n) / SR
    place(dn, lp(noise(n), 500) * np.sin(np.pi * tt / 2.1) ** 2, c0, 1)
    cn = int(SR * 1.0); ct = np.arange(cn) / SR
    chirp = np.sin(2 * np.pi * 4300 * ct) * (np.sin(2 * np.pi * 26 * ct) > .3) * np.sin(np.pi * ct / 1.0)
    place(dn, chirp * .5, c0 + .55, 1)
add(dn, db(-20), width=.01)
# hurricane: a storm howl that dies out
howl = bp(noise(), 300, 900) * (0.5 + .5 * np.sin(2 * np.pi * .7 * t))
add(howl * env([(108.4, 0), (109.6, 1), (110.6, 1), (112.4, 0)]), db(-17), width=.02)

# ---------- 16. end card: last low note ----------
endn = np.zeros(N); n = int(SR * 5); tt = np.arange(n) / SR
place(endn, (np.sin(2 * np.pi * 55 * tt) + .4 * np.sin(2 * np.pi * 110 * tt)) * np.minimum(1, tt / .05) * np.exp(-tt * .9), 124.9, 1)
add(endn, db(-22))

# ---------- master ----------
mix = np.stack([L, R], 1)
mix = hp(mix.T, 25).T
mix = mix / np.percentile(np.abs(mix), 99.95) * db(-3)
mix = np.tanh(mix * 1.4) / np.tanh(1.4)
mix = mix / np.abs(mix).max() * db(-1.0)
fade = np.ones(N); fade[-int(SR * .5):] = np.linspace(1, 0, int(SR * .5)); mix *= fade[:, None]
wavfile.write(f'{ROOT}/audio.wav', SR, (mix * 32767).astype(np.int16))
blk = SR * 5; rms = [20 * np.log10(np.sqrt(np.mean(mix[i:i + blk] ** 2)) + 1e-9) for i in range(0, N, blk)]
print('dB per 5 s:', [round(x, 1) for x in rms])
