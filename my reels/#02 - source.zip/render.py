import sys, json, base64, subprocess, time, os
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.abspath(__file__))
tl = json.load(open(f'{ROOT}/timeline.json'))
land = json.load(open(f'{ROOT}/node_modules/world-atlas/land-110m.json'))
def page_ready(p):
    page = p.chromium.launch(args=['--disable-gpu']).new_page(viewport={'width':1080,'height':1920})
    page.goto(f'file://{ROOT}/reel.html')
    page.evaluate('([tl, land]) => setup(tl, land)', [tl, land])
    page.evaluate('document.fonts.load("400 40px Tinos")'); page.evaluate('document.fonts.load("italic 400 40px Tinos")')
    page.evaluate('document.fonts.ready.then(()=>1)')
    return page
def grab(page, t, q=0.93):
    url = page.evaluate(f'(()=>{{renderFrame({t}); return document.getElementById("c").toDataURL("image/jpeg",{q});}})()')
    return base64.b64decode(url.split(',')[1])
if __name__ == '__main__':
    mode = sys.argv[1]
    with sync_playwright() as p:
        page = page_ready(p)
        errs = []; page.on('pageerror', lambda e: errs.append(str(e)))
        if mode == 'preview':
            out = sys.argv[2]; os.makedirs(out, exist_ok=True)
            for t in [float(x) for x in sys.argv[3:]]:
                open(f'{out}/f_{t:06.1f}.jpg','wb').write(grab(page, t, .9))
        elif mode == 'video':
            out, t0, t1 = sys.argv[2], float(sys.argv[3]), float(sys.argv[4])
            fps = tl['fps']; n0, n1 = round(t0*fps), round(t1*fps)
            ff = subprocess.Popen(['ffmpeg','-y','-v','error','-f','image2pipe','-framerate',str(fps),'-c:v','mjpeg','-i','-','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p',out], stdin=subprocess.PIPE)
            st = time.time()
            for n in range(n0, n1):
                ff.stdin.write(grab(page, n / fps))
                if n % 300 == 0: print(n, round(time.time()-st,1), flush=True)
            ff.stdin.close(); ff.wait()
        if errs: print('PAGE ERRORS:', errs[:5])
