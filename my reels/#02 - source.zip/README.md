# What if the oceans drained? — reel source

Everything in the reel is generated from code, so you can change any word, number or timing and re-render.

## Files
- `timeline.json` — the script: captions (start, end, text), counters, water-level keyframes, scene times, end card. Edit this first.
- `reel.html` — draws every frame on a 1080×1920 canvas (beach, descent + Titanic, Mariana Trench + Everest, globe consequences, the coast afterwards, end card).
- `audio.py` — procedural sound design on the same timeline (surf, gulls, wind, drone, silence drop, Titanic groan, trench roar, salt shimmer, rain stopping, day/night swells, hurricane dying out).
- `render.py` — renders frames through headless Chromium and pipes them to ffmpeg.

## Re-render (Windows, from this folder)
```
npm i @fontsource/tinos d3-geo d3-array topojson-client world-atlas
pip install playwright numpy scipy
python -m playwright install chromium
python render.py preview prev 10 30 70 104      # check a few frames as JPGs
python render.py video video_raw.mp4 0 131      # ~6 min
python audio.py                                 # writes audio.wav
ffmpeg -i video_raw.mp4 -i audio.wav -c:v copy -c:a aac -b:a 256k -movflags +faststart -shortest final.mp4
```

## Easy changes
- Your handle as a watermark: add a `ctx.fillText('@yourhandle', …)` line in `renderFrame` in `reel.html`.
- Rewatch hook: `endCard.hook` in `timeline.json` (the duck rides the water all the way down to the bottom of the trench).
- Pacing: move caption times and the matching `waterLevel` keyframes together.

## Facts used (all checked)
Titanic ~3,800 m down, ~600 km SSE of Newfoundland, bow and stern ~600 m apart, sank 1912 · Bering Strait 30–50 m deep on average (90 m max) · last ice age sea level ~125 m lower, ~21,000 years ago · little light below 200 m, darkness from ~1,000 m (NOAA) · average ocean depth 3,682 m (NOAA) · Challenger Deep ~10,935 m · Everest 8,848.86 m · ocean covers ~71% of Earth · humans have seen less than 0.001% of the deep seafloor (NOAA) · ocean salt would cover all land more than 166 m deep (USGS) · the ocean supplies 86% of global evaporation (NASA) · roughly half of Earth's oxygen production comes from the ocean (NOAA) · the ocean has absorbed about 90% of the extra heat from global warming (NASA) · hurricanes need seawater of at least 26.5 °C (NOAA).
